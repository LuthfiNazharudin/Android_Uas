package com.lupi.resep;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {


    private ImageView tahu;
    private ImageView pecak;
    private ImageView gemblong;
    private ImageView glotak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setContentView(R.layout.activity_main);
        tahu= (ImageView) findViewById(R.id.iv_resep1);
        //inten tahu
        tahu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tahue = new Intent(getApplicationContext(), TahuAci.class);
                startActivity(tahue);


                setContentView(R.layout.activity_main);
                pecak = (ImageView) findViewById(R.id.iv_resep2);
                //inten pecak
                pecak.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent pecake = new Intent(getApplicationContext(), PecakPatiTerong.class);
                        startActivity(pecake);


                        setContentView(R.layout.activity_main);
                        gemblong = (ImageView) findViewById(R.id.iv_resep3);
                        //inten gemblong
                        gemblong.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent gemblonge = new Intent(getApplicationContext(), Gemblong.class);
                                startActivity(gemblonge);


                                setContentView(R.layout.activity_main);
                                glotak = (ImageView) findViewById(R.id.iv_resep4);
                                //inten glotak
                                glotak.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Intent glotake = new Intent(getApplicationContext(), Glotak.class);
                                        startActivity(glotake);
                                    }
                                });
                            }
                        });
                    }

                });
            }

        });
    }
}