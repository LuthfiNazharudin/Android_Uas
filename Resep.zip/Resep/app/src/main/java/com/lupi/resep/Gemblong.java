package com.lupi.resep;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Gemblong extends AppCompatActivity {
    private Button mback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gemblong);

        mback = (Button) findViewById(R.id.backmenu);

        mback.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent backmenu = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(backmenu);
            }
        });
    }
}
